package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.Bean.LoginBean;

@Controller
public class Controllerclass 
{
	
	@RequestMapping(value="/")
	public String Loginpage(@ModelAttribute("login")LoginBean lbean)
	{
		return "loginpage";
	}

}
